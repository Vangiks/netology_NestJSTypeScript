const express = require('express');
const serverless = require('serverless-http');
const fetch = require('node-fetch');

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.get('/api/characters', (request, response) => {
  const result = fetch(
    `https://netology-api-marvel.herokuapp.com/characters`
  ).then((response) => response.json());

  response.json(result);
});

module.exports.handler = serverless(app);
